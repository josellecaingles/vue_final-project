<template>
    <div>
      <h1>Merchandise List</h1>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Brand</th>
            <th>Description</th>
            <th>Retail Price</th>
            <th>Whole Sale Price</th>
            <th>Wole Sale Qty</th>
            <th>Qty Stock</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="merchandise in merchandises" :key="merchandise.id">
            <td>{{ merchandise.id }}</td>
            <td>{{ merchandise.brand }}</td>
            <td>{{ merchandise.description }}</td>
            <td>{{ merchandise.retail_price }}</td>
            <td>{{ merchandise.whole_sale_price }}</td>
            <td>{{ merchandise.whole_sale_qty }}</td>
            <td>{{ merchandise.qty_stock }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  import { ref, onMounted } from 'vue';
  import axios from 'axios';
  
  export default {
    setup() {
      const merchandises = ref([]);
  
      onMounted(async () => {
        try {
          const response = await axios.get('http://localhost:8000/api/merchandises');
          merchandises.value = response.data;
        } catch (error) {
          console.error('Error fetching merchandises:', error);
        }
      });
  
      return {
        merchandises,
      };
    },
  };
  </script>
  
  <style scoped>
  .merchandise-list {
  margin: 20px;
}

h1 {
  color: #333;
  text-align: center;
  font-family: Georgia, 'Times New Roman', Times, serif;
}


table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 10px;
}

th, td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
  background-color: rgb(121, 149, 160);

}

th {
  background-color: rgb(203, 242, 159);
  text-align: center;
}
  </style>
  